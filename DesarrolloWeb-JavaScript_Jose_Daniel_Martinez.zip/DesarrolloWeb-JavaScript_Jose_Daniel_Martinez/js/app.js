function MainCalculadora(){
    
   //Declarando variables para obtener los Id del teclado
    
    //###### Variables para seleccionar las teclas ######/
      var numero1 = document.getElementById("1");
      var numero2 = document.getElementById("2");
      var numero3 = document.getElementById("3");
      var numero4 = document.getElementById("4");
      var numero5 = document.getElementById("5");
      var numero6 = document.getElementById("6");
      var numero7 = document.getElementById("7");
      var numero8 = document.getElementById("8");
      var numero9 = document.getElementById("9");
      var numero0 = document.getElementById("0");
      var punto = document.getElementById("punto");
      var igual = document.getElementById("igual");
      var mas = document.getElementById("mas");
      var menos = document.getElementById("menos");
      var multiplicar = document.getElementById("por");
      var dividir = document.getElementById("dividido");
      var limpiar = document.getElementById("on");
      var pantalla = document.getElementById("display");
      var negativo = document.getElementById("sign");
       //###### Variables para seleccionar las teclas ######/
    
       //###### Variables para mostrar los numeros en pantalla ######/
    
        var printcero;
        var printuno;
        var printdos;
        
       //###### Variables para mostrar los numeros en pantalla ######/
    
    
    var primeroperando;
    var validacioncantidades;
    var segundooperando;
    var operacion;
    var cantidad = 0;
    
    numero1.addEventListener('mousedown', function(){
        numero1.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero1.addEventListener('mouseup',function(){
            numero1.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
        
        numero1.onclick = function(e){
       
        if(cantidad < "8"){
            
                 if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "1";          
          
                }else{
                   
                        pantalla.textContent =  "1";
                     
                }
        }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
        }      
 
          validacioncantidades = pantalla.textContent;
          cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
            
        } 
       

    });
    
      numero2.addEventListener('mousedown', function(){
        numero2.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero2.addEventListener('mouseup',function(){
            numero2.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
          
            numero2.onclick = function(e){
                
           if(cantidad < "8"){
             if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "2";
                }else{
                   
                        pantalla.textContent =  "2";
                }
            }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
            } 
              validacioncantidades = pantalla.textContent;
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
        }
          
    });
    
      numero3.addEventListener('mousedown', function(){
        numero3.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero3.addEventListener('mouseup',function(){
            numero3.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
        
           numero3.onclick = function(e){
            if(cantidad < "8"){    
               
            if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "3";
                }else{
                   
                        pantalla.textContent =  "3";
                }
            
            }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
            } 
               
           validacioncantidades = pantalla.textContent;
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
         } 
          
    });
      numero4.addEventListener('mousedown', function(){
        numero4.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero4.addEventListener('mouseup',function(){
            numero4.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
          
         numero4.onclick = function(e){
          if(cantidad < "8"){    
          if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "4";
                }else{
                   
                        pantalla.textContent =  "4";
                }
          }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
        } 
           validacioncantidades = pantalla.textContent;
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
         }
    });
      numero5.addEventListener('mousedown', function(){
        numero5.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero5.addEventListener('mouseup',function(){
            numero5.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
          
         numero5.onclick = function(e){
        if(cantidad < "8"){       
          if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "5";
                }else{
                   
                        pantalla.textContent =  "5";
                }
            }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
        } 
          validacioncantidades = pantalla.textContent;
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad); 
         }
    });
      numero6.addEventListener('mousedown', function(){
        numero6.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero6.addEventListener('mouseup',function(){
            numero6.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
           numero6.onclick = function(e){
           if(cantidad < "8"){      
           if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "6";
                }else{
                   
                        pantalla.textContent =  "6";
                }
            }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
        } 
          validacioncantidades = pantalla.textContent; 
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
           }
        
    });
      numero7.addEventListener('mousedown', function(){
        numero7.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero7.addEventListener('mouseup',function(){
            numero7.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
        
           numero7.onclick = function(e){
        if(cantidad < "8"){        
           if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "7";
                }else{
                   
                        pantalla.textContent =  "7";
                }
             }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
         } 
           validacioncantidades = pantalla.textContent;  
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
           }
          
    });
      numero8.addEventListener('mousedown', function(){
        numero8.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero8.addEventListener('mouseup',function(){
            numero8.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
        
           numero8.onclick = function(e){
           if(cantidad < "8"){     
           if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "8";
                }else{
                   
                        pantalla.textContent =  "8";
                }
           }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
         } 
               
          validacioncantidades = pantalla.textContent;  
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
           }
          
    });
   
          numero9.addEventListener('mousedown', function(){
        numero9.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero9.addEventListener('mouseup',function(){
            numero9.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
        
            numero9.onclick = function(e){
            if(cantidad < "8"){ 
                if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "9";
                    
                    
                }else{
                   
                        pantalla.textContent =  "9";
                }
            }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
         } 
           validacioncantidades = pantalla.textContent;  
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
            }
    });
    
      numero0.addEventListener('mousedown', function(){
        numero0.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        numero0.addEventListener('mouseup',function(){
            numero0.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
        
         
            numero0.onclick = function(e){  
            if(cantidad < "8"){ 
                if(pantalla.textContent != "0"){
                    pantalla.textContent = pantalla.textContent + "0";
                }else{
                   
                        pantalla.textContent =  "0";
                }
             }else{
            console.log("la cantidad no puede ser mayor a 8: " + cantidad);
          }     
           validacioncantidades = pantalla.textContent; 
           cantidad = validacioncantidades.toString().length;
           console.log("cantidad: "+ cantidad);
            }
          
          
    });
    
  
    
       punto.addEventListener('mousedown', function(){
        punto.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        punto.addEventListener('mouseup',function(){
            punto.style.padding = "0%";
            console.log("El boton ya no esta presionado");
            
        });
           
               punto.onclick = function(e){  
          
                if(pantalla.textContent != "0"){
                    
                    var valorpunto = pantalla.textContent;
                   
                    console.log(valorpunto.includes('.'));
                    if(valorpunto.includes('.')){
                       
                       
                    }else{
                         pantalla.textContent = pantalla.textContent + ".";
                    }
                    
                }else{
                   
                        pantalla.textContent = pantalla.textContent + ".";
                }
          
            }
          
        
    });
    
        negativo.addEventListener('mousedown', function(){
        negativo.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        negativo.addEventListener('mouseup',function(){
            negativo.style.padding = "0%";
            console.log("El boton ya no esta presionado");
            
        });
           
               negativo.onclick = function(e){  
          
                if(pantalla.textContent != "0"){
                    
                    var valorpunto = pantalla.textContent;
                   
                    console.log(valorpunto.includes('-'));
                    if(valorpunto.includes('-')){
                       
                       
                    }else{
                         pantalla.textContent = "-" + pantalla.textContent ;
                    }
                    
                }else{
                   
                        //pantalla.textContent =  "-" + pantalla.textContent;
                }
          
            }
          
        
    });
    
    
       igual.addEventListener('mousedown', function(){
        igual.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        igual.addEventListener('mouseup',function(){
            igual.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
        
    });
    
    
     mas.addEventListener('mousedown', function(){
        mas.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        mas.addEventListener('mouseup',function(){
            mas.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
         
     });
        menos.addEventListener('mousedown', function(){
        menos.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        menos.addEventListener('mouseup',function(){
            menos.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
     });  
    
        multiplicar.addEventListener('mousedown', function(){
        multiplicar.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        multiplicar.addEventListener('mouseup',function(){
            multiplicar.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
       
       }); 
       dividir.addEventListener('mousedown', function(){
        dividir.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        dividir.addEventListener('mouseup',function(){
            dividir.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
       
       }); 
    
          limpiar.addEventListener('mousedown', function(){
        limpiar.style.padding = "1%";
        console.log("El boton esta siendo presionado");
        limpiar.addEventListener('mouseup',function(){
            limpiar.style.padding = "0%";
            console.log("El boton ya no esta presionado");
        });
       
       }); 
        
limpiar.onclick = function(e){
    
    resetearcal();
    pantalla.textContent = "0";
}

mas.onclick = function(e){
    primeroperando = pantalla.textContent;
    operacion = "+"
    console.log("valor primer operando:" + primeroperando);
    limpiarcal();    
 
   
 
}

menos.onclick = function(e){
    primeroperando = pantalla.textContent;
    operacion = "-"
    limpiarcal();   
    
}

multiplicar.onclick = function(e){
    primeroperando = pantalla.textContent;
    operacion = "*"
    limpiarcal();
     
}

dividir.onclick = function(e){
    primeroperando = pantalla.textContent;
    operacion = "/"
    limpiarcal();
}

igual.onclick = function (e){
    segundooperando = pantalla.textContent;
   console.log("valor primer operando: " + primeroperando);
    console.log("valor segundo operando: " + segundooperando);
    ResolverOperacion(primeroperando, segundooperando);
   
    
}
    
function limpiarcal(){
    pantalla.textContent = "";
    
}
    
function resetearcal(){
    
    pantalla.textContent = "";
    primeroperando = 0;
    segundooperando = 0;
    operacion = "";
    
}
    function ResolverOperacion(primerargumento, segundoargumento){
        
        var res = 0;
        switch(operacion){
                
            case "+":
                res = parseFloat(primerargumento) + parseFloat(segundoargumento);
                break;
            case "-":
                 res = parseFloat(primeroperando) - parseFloat(segundooperando);
                break;
            case "*":
                 res = parseFloat(primeroperando) * parseFloat(segundooperando);
                break;  
            case "/":
                 res = parseFloat(primeroperando) / parseFloat(segundooperando);
                break;
        }
        resetearcal();
        pantalla.textContent = res;
                
    }
    
}

